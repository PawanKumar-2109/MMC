Chainlink using solidity 0.5.0

To get this to run, you might need to `yarn install --upgrade` in the chainlink root directory.
